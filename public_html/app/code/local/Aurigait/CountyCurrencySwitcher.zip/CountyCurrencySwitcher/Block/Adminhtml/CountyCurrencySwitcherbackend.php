<?php  

class Aurigait_CountyCurrencySwitcher_Block_Adminhtml_CountyCurrencySwitcherbackend extends Mage_Adminhtml_Block_Template {

}