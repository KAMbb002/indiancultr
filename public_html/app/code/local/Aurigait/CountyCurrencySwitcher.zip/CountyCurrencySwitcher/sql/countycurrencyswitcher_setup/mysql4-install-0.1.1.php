<?php
$installer = $this;
$installer->startSetup();
/*
$installer->addAttribute("catalog_product", "shipping_not_allowed_countries",  array(
   "type"     => "int",
   "backend"  => "",
   "frontend" => "",
   "label"    => "Shipping Not Allowed in Countries",
   "input"    => "multiselect",
   "class"    => "",
   "source"   => "countycurrencyswitcher/eav_entity_attribute_source_options",
   "global"   => Mage_Catalog_Model_Resource_Eav_Attribute::SCOPE_GLOBAL,
   "visible"  => true,
   "required" => false,
   "is_user_defined"  => true,
   "default" => "0",
   "searchable" => false,
   "filterable" => false,
   "comparable" => false,
   "used_for_sort_by" => true,
   "visible_on_front"  => false,
   "unique"     => false,
   "system" => true,
   "note"       => ""

       ));
*/
$installer->endSetup();
	 