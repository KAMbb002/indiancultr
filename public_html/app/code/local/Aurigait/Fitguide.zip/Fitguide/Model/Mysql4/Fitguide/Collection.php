<?php
    class Aurigait_Fitguide_Model_Mysql4_Fitguide_Collection extends Mage_Core_Model_Mysql4_Collection_Abstract
    {

		public function _construct(){
			$this->_init("fitguide/fitguide");
		}

		

    }
	 