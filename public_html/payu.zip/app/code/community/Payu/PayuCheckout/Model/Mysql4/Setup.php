<?php

class Payu_PayuCheckout_Model_Mysql4_Setup extends Mage_Sales_Model_Mysql4_Setup
{

}
